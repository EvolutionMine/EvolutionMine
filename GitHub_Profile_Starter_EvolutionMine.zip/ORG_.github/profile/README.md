# Evolution Mine — Bioeconomy Ops

[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.17179859.svg)](https://doi.org/10.5281/zenodo.17179859)  
Open science + open operations to replace petrochemical supply chains with **hemp & bamboo** systems.

## Focus
- Evidence‑backed narrative & datasets (The Wall) · DOI `10.5281/zenodo.17179859`
- Processor network maps (AFG) · M&A/PPM roll‑up thesis
- Product pipelines: DTC → B2B → industrial composites
- Compliance & incentives: FEOC, DC, 45X/48C, §6417/§6418

## Repos
- **thewall** — executive summary + evidence wall → https://github.com/EvolutionMine/thewall
- **fiberfoundry** — storefront + ops (coming soon)
- **afg‑ppm** — processor atlas + PPM vault (private until ready)

## Contributing
- PRs welcome on **thewall** (`data/evidence_wall.csv`) following schema.
- Issues: source suggestions, corrections, or processor updates.

**Contact:** eric@… | nowweevolve.com
